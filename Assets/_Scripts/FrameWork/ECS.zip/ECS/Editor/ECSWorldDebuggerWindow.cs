#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace ECSFrameWork
{
/// <summary>
/// ECS World 独立调试窗口。
/// 该窗口只通过 World Debug API 读取数据，不访问 ECS 内部 Manager / Store 字段。
/// </summary>
public sealed class ECSWorldDebuggerWindow : EditorWindow
{
    private enum DebuggerTab
    {
        Overview = 0,
        Entities = 1,
        Systems = 2,
        ArcheTypes = 3,
        ComponentStores = 4,
        Singletons = 5,
        WorldEvents = 6
    }

    private const double DefaultRefreshInterval = 0.25d;
    private const int MaxPreviewCount = 256;

    private static readonly string[] TabNames =
    {
        "Overview",
        "Entities",
        "Systems",
        "ArcheTypes",
        "Component Stores",
        "Singletons",
        "World Events"
    };

    private readonly List<IECSRuntimeDebugSource> _sources = new List<IECSRuntimeDebugSource>(8);
    private readonly List<string> _sourceLabels = new List<string>(8);
    private string[] _sourceLabelArray = Array.Empty<string>();

    private readonly List<Entity> _entities = new List<Entity>(256);
    private readonly List<Entity> _archeTypeEntities = new List<Entity>(128);
    private readonly List<Type> _componentTypes = new List<Type>(32);
    private readonly List<ComponentStoreDebugInfo> _componentStores = new List<ComponentStoreDebugInfo>(32);
    private readonly List<ArcheTypeDebugInfo> _archeTypes = new List<ArcheTypeDebugInfo>(32);
    private readonly List<SystemDebugInfo> _systems = new List<SystemDebugInfo>(32);
    private readonly List<SingletonDebugInfo> _singletons = new List<SingletonDebugInfo>(16);
    private readonly List<WorldEventDebugInfo> _events = new List<WorldEventDebugInfo>(16);

    private Vector2 _mainScroll;
    private Vector2 _entityListScroll;
    private Vector2 _entityDetailScroll;
    private Vector2 _archeTypeListScroll;
    private Vector2 _archeTypeDetailScroll;

    private DebuggerTab _currentTab = DebuggerTab.Overview;
    private WorldDebugSnapshot _snapshot;
    private bool _hasData;
    private bool _autoRefresh = true;
    private float _refreshInterval = (float)DefaultRefreshInterval;
    private double _nextRefreshTime;
    private int _selectedSourceIndex = -1;
    private int _selectedEntityIndex = -1;
    private int _selectedArcheTypeIndex = -1;
    private string _entitySearch = string.Empty;
    private string _systemSearch = string.Empty;
    private string _componentStoreSearch = string.Empty;
    private string _lastRefreshError = string.Empty;

    /// <summary>打开 ECS World Debugger 窗口。</summary>
    [MenuItem("Window/ECSFrameWork/World Debugger")]
    public static void Open()
    {
        ECSWorldDebuggerWindow window = GetWindow<ECSWorldDebuggerWindow>("ECS Debugger");
        window.minSize = new Vector2(680f, 420f);
        window.Show();
    }

    /// <summary>窗口启用时刷新可用调试目标。</summary>
    private void OnEnable()
    {
        RefreshTargets();
        RefreshData();
    }

    /// <summary>绘制 ECS World Debugger 主界面。</summary>
    private void OnGUI()
    {
        DrawHeader();
        DrawTargetToolbar();
        DrawRefreshToolbar();
        DrawPlayModeNotice();
        RefreshIfNeeded();

        if (!string.IsNullOrEmpty(_lastRefreshError))
            EditorGUILayout.HelpBox(_lastRefreshError, MessageType.Error);

        IECSRuntimeDebugSource source = GetCurrentSource();
        World world = GetCurrentWorld();

        if (source == null)
        {
            EditorGUILayout.HelpBox("No IECSRuntimeDebugSource found in the current scene. Use TimeSimulator or ECSRuntimeDebugTarget as debug source.", MessageType.Info);
            return;
        }

        if (world == null)
        {
            EditorGUILayout.HelpBox("Selected debug source has no bound World. Make sure the runtime bootstrap has initialized and bound World / SimulateRunner.", MessageType.Warning);
            return;
        }

        if (!_hasData)
        {
            EditorGUILayout.HelpBox("No debug data has been refreshed yet.", MessageType.Info);
            return;
        }

        int nextTab = GUILayout.Toolbar((int)_currentTab, TabNames);
        _currentTab = (DebuggerTab)nextTab;

        _mainScroll = EditorGUILayout.BeginScrollView(_mainScroll);
        switch (_currentTab)
        {
            case DebuggerTab.Overview:
                DrawOverviewTab(source);
                break;
            case DebuggerTab.Entities:
                DrawEntitiesTab(world);
                break;
            case DebuggerTab.Systems:
                DrawSystemsTab();
                break;
            case DebuggerTab.ArcheTypes:
                DrawArcheTypesTab(world);
                break;
            case DebuggerTab.ComponentStores:
                DrawComponentStoresTab();
                break;
            case DebuggerTab.Singletons:
                DrawSingletonsTab();
                break;
            case DebuggerTab.WorldEvents:
                DrawWorldEventsTab();
                break;
        }
        EditorGUILayout.EndScrollView();
    }

    /// <summary>自动刷新开启时让窗口持续重绘。</summary>
    private void Update()
    {
        if (_autoRefresh && Application.isPlaying)
            Repaint();
    }

    /// <summary>绘制窗口标题。</summary>
    private void DrawHeader()
    {
        EditorGUILayout.Space(4f);
        EditorGUILayout.LabelField("ECS World Debugger", EditorStyles.boldLabel);
        EditorGUILayout.Space(2f);
    }

    /// <summary>绘制调试目标选择工具栏。</summary>
    private void DrawTargetToolbar()
    {
        EditorGUILayout.BeginHorizontal();

        if (GUILayout.Button("Refresh Targets", GUILayout.Width(120f)))
        {
            RefreshTargets();
            RefreshData();
        }

        if (_sourceLabelArray.Length == 0)
        {
            _selectedSourceIndex = -1;
            EditorGUILayout.Popup("Debug Target", 0, new[] { "None" });
        }
        else
        {
            int nextIndex = EditorGUILayout.Popup("Debug Target", Mathf.Max(0, _selectedSourceIndex), _sourceLabelArray);
            if (nextIndex != _selectedSourceIndex)
            {
                _selectedSourceIndex = nextIndex;
                _selectedEntityIndex = -1;
                _selectedArcheTypeIndex = -1;
                RefreshData();
            }
        }

        IECSRuntimeDebugSource source = GetCurrentSource();
        EditorGUI.BeginDisabledGroup(!(source is UnityEngine.Object));
        if (GUILayout.Button("Ping", GUILayout.Width(60f)))
        {
            UnityEngine.Object targetObject = source as UnityEngine.Object;
            if (targetObject != null)
            {
                Selection.activeObject = targetObject;
                EditorGUIUtility.PingObject(targetObject);
            }
        }
        EditorGUI.EndDisabledGroup();

        EditorGUILayout.EndHorizontal();
    }

    /// <summary>绘制刷新控制工具栏。</summary>
    private void DrawRefreshToolbar()
    {
        EditorGUILayout.BeginHorizontal();
        _autoRefresh = GUILayout.Toggle(_autoRefresh, "Auto Refresh", "Button", GUILayout.Width(110f));
        _refreshInterval = EditorGUILayout.Slider("Interval", _refreshInterval, 0.05f, 2f);

        if (GUILayout.Button("Refresh Now", GUILayout.Width(110f)))
            RefreshData();

        if (GUILayout.Button("Dump Snapshot", GUILayout.Width(120f)))
        {
            RefreshData();
            if (_hasData)
                Debug.Log($"[ECS World Debugger] {_snapshot}");
        }

        EditorGUILayout.EndHorizontal();
    }

    /// <summary>绘制 PlayMode 提示。</summary>
    private void DrawPlayModeNotice()
    {
        if (Application.isPlaying)
            return;

        EditorGUILayout.HelpBox("World Debugger reads runtime data. Enter Play Mode and select a bound debug source to inspect ECS state.", MessageType.Info);
    }

    /// <summary>根据自动刷新间隔刷新 Debug 数据。</summary>
    private void RefreshIfNeeded()
    {
        if (!_autoRefresh || !Application.isPlaying)
            return;

        double time = EditorApplication.timeSinceStartup;
        if (time < _nextRefreshTime)
            return;

        RefreshData();
        _nextRefreshTime = time + Math.Max(0.05f, _refreshInterval);
    }

    /// <summary>刷新当前场景中可用的 ECS 调试源。</summary>
    private void RefreshTargets()
    {
        _sources.Clear();
        _sourceLabels.Clear();

        MonoBehaviour[] behaviours = UnityEngine.Object.FindObjectsOfType<MonoBehaviour>(true);
        for (int i = 0; i < behaviours.Length; i++)
        {
            MonoBehaviour behaviour = behaviours[i];
            if (behaviour == null)
                continue;

            IECSRuntimeDebugSource source = behaviour as IECSRuntimeDebugSource;
            if (source == null)
                continue;

            _sources.Add(source);
            _sourceLabels.Add(CreateSourceLabel(source));
        }

        _sourceLabelArray = _sourceLabels.ToArray();

        if (_sources.Count == 0)
        {
            _selectedSourceIndex = -1;
            _hasData = false;
            ClearCachedData();
            return;
        }

        if (_selectedSourceIndex < 0 || _selectedSourceIndex >= _sources.Count)
            _selectedSourceIndex = 0;
    }

    /// <summary>刷新当前调试源的 World Debug 数据。</summary>
    private void RefreshData()
    {
        _lastRefreshError = string.Empty;
        ClearCachedData();

        World world = GetCurrentWorld();
        if (world == null)
        {
            _hasData = false;
            return;
        }

        try
        {
            _snapshot = world.GetDebugSnapshot();
            world.FillAliveEntities(_entities);
            world.FillComponentStoreDebugInfos(_componentStores);
            world.FillArcheTypeDebugInfos(_archeTypes);
            world.FillSystemDebugInfos(_systems);
            world.FillSingletonDebugInfos(_singletons);
            world.FillWorldEventDebugInfos(_events);
            _hasData = true;

            if (_selectedEntityIndex >= _entities.Count)
                _selectedEntityIndex = -1;

            if (_selectedArcheTypeIndex >= _archeTypes.Count)
                _selectedArcheTypeIndex = -1;
        }
        catch (Exception exception)
        {
            _hasData = false;
            _lastRefreshError = exception.Message;
            Debug.LogException(exception);
        }
    }

    /// <summary>清空当前窗口缓存的 Debug 数据。</summary>
    private void ClearCachedData()
    {
        _entities.Clear();
        _archeTypeEntities.Clear();
        _componentTypes.Clear();
        _componentStores.Clear();
        _archeTypes.Clear();
        _systems.Clear();
        _singletons.Clear();
        _events.Clear();
    }

    /// <summary>绘制总览页。</summary>
    private void DrawOverviewTab(IECSRuntimeDebugSource source)
    {
        EditorGUILayout.LabelField("Overview", EditorStyles.boldLabel);
        DrawReadOnlyText("Source", source != null ? source.DebugSourceName : "None");
        DrawReadOnlyText("World State", _snapshot.currentState.ToString());
        DrawReadOnlyInt("Created Entities", _snapshot.statistics.createdEntityCount);
        DrawReadOnlyInt("Alive Entities", _snapshot.statistics.aliveEntityCount);
        DrawReadOnlyInt("Free Entities", _snapshot.statistics.freeEntityCount);
        DrawReadOnlyInt("Entity Capacity", _snapshot.entityCapacity);
        DrawReadOnlyInt("Component Types", _snapshot.componentTypeCount);
        DrawReadOnlyInt("Component Stores", _snapshot.componentStoreCount);
        DrawReadOnlyInt("ArcheTypes", _snapshot.archeTypeCount);
        DrawReadOnlyInt("Query Cache", _snapshot.queryCacheCount);
        DrawReadOnlyInt("ArcheType Version", _snapshot.statistics.archeTypeVersion);
        DrawReadOnlyInt("Systems", _snapshot.systemCount);
        DrawReadOnlyInt("Singletons", _snapshot.singletonCount);
        DrawReadOnlyInt("WorldEvent Types", _snapshot.worldEventTypeCount);
        DrawReadOnlyInt("WorldEvents", _snapshot.worldEventCount);
        DrawReadOnlyInt("Pending Structural Changes", _snapshot.pendingStructuralChangeCount);
        DrawReadOnlyInt("Pending System Changes", _snapshot.pendingSystemChangeCount);

        SimulateRunner runner = source != null ? source.DebugRunner : null;
        EditorGUILayout.Space(8f);
        EditorGUILayout.LabelField("Runner", EditorStyles.boldLabel);
        if (runner == null)
        {
            EditorGUILayout.HelpBox("No SimulateRunner is bound to this debug source.", MessageType.Info);
            return;
        }

        DrawReadOnlyInt("Frame Count", runner.FrameCount);
        DrawReadOnlyInt("Current Frame", runner.CurrentFrameNumber);
        DrawReadOnlyInt("Next Frame", runner.NextFrameNumber);
        DrawReadOnlyText("Is Ticking", runner.IsTicking.ToString());
        DrawReadOnlyFloat("Tick Length", runner.TickLength);
        DrawReadOnlyFloat("Tick Counter", runner.TickCounter);
    }

    /// <summary>绘制实体列表与选中实体详情。</summary>
    private void DrawEntitiesTab(World world)
    {
        EditorGUILayout.LabelField($"Entities ({_entities.Count})", EditorStyles.boldLabel);
        _entitySearch = EditorGUILayout.TextField("Search", _entitySearch);

        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.BeginVertical(GUILayout.Width(position.width * 0.45f));
        _entityListScroll = EditorGUILayout.BeginScrollView(_entityListScroll, GUILayout.MinHeight(280f));

        int shownCount = 0;
        for (int i = 0; i < _entities.Count; i++)
        {
            Entity entity = _entities[i];
            if (!EntityMatchesSearch(entity, _entitySearch))
                continue;

            if (shownCount >= MaxPreviewCount)
                break;

            bool selected = i == _selectedEntityIndex;
            string label = $"{entity}    Components={GetComponentCount(world, entity)}";
            if (GUILayout.Toggle(selected, label, "Button"))
                _selectedEntityIndex = i;

            shownCount++;
        }

        EditorGUILayout.EndScrollView();
        if (_entities.Count > MaxPreviewCount)
            EditorGUILayout.HelpBox($"Only first {MaxPreviewCount} matched entities are shown.", MessageType.Info);
        EditorGUILayout.EndVertical();

        EditorGUILayout.BeginVertical();
        _entityDetailScroll = EditorGUILayout.BeginScrollView(_entityDetailScroll, GUILayout.MinHeight(280f));
        DrawSelectedEntityDetail(world);
        EditorGUILayout.EndScrollView();
        EditorGUILayout.EndVertical();
        EditorGUILayout.EndHorizontal();
    }

    /// <summary>绘制选中实体详情。</summary>
    private void DrawSelectedEntityDetail(World world)
    {
        if (_selectedEntityIndex < 0 || _selectedEntityIndex >= _entities.Count)
        {
            EditorGUILayout.HelpBox("Select an Entity from the left list.", MessageType.Info);
            return;
        }

        Entity entity = _entities[_selectedEntityIndex];
        if (!world.TryGetEntityDebugInfo(entity, out EntityDebugInfo info))
        {
            EditorGUILayout.HelpBox($"{entity} is no longer alive.", MessageType.Warning);
            return;
        }

        EditorGUILayout.LabelField("Selected Entity", EditorStyles.boldLabel);
        DrawReadOnlyInt("ID", entity.ID);
        DrawReadOnlyInt("Version", entity.Version);
        DrawReadOnlyText("Alive", info.isAlive.ToString());
        DrawReadOnlyInt("Component Count", info.componentCount);
        DrawReadOnlyText("Mask", info.componentMask.ToString());

        EditorGUILayout.Space(6f);
        EditorGUILayout.LabelField("Components", EditorStyles.boldLabel);
        world.FillEntityComponentTypes(entity, _componentTypes);
        DrawTypeList(_componentTypes);
    }

    /// <summary>绘制 System 调试页。</summary>
    private void DrawSystemsTab()
    {
        EditorGUILayout.LabelField($"Systems ({_systems.Count})", EditorStyles.boldLabel);
        _systemSearch = EditorGUILayout.TextField("Search", _systemSearch);
        DrawSystemHeader();

        for (int i = 0; i < _systems.Count; i++)
        {
            SystemDebugInfo info = _systems[i];
            if (!TextMatches(info.name, _systemSearch) && !TextMatches(ShortTypeName(info.systemType), _systemSearch))
                continue;

            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField(info.name, GUILayout.MinWidth(160f));
            EditorGUILayout.LabelField(info.sequence.ToString(), GUILayout.Width(100f));
            EditorGUILayout.LabelField(info.enabled.ToString(), GUILayout.Width(60f));
            EditorGUILayout.LabelField(info.lastTickMilliseconds.ToString("F4"), GUILayout.Width(80f));
            EditorGUILayout.LabelField(info.averageTickMilliseconds.ToString("F4"), GUILayout.Width(80f));
            EditorGUILayout.LabelField(info.maxTickMilliseconds.ToString("F4"), GUILayout.Width(80f));
            EditorGUILayout.LabelField(info.tickCount.ToString(), GUILayout.Width(80f));
            EditorGUILayout.EndHorizontal();
        }
    }

    /// <summary>绘制 ArcheType 分组页。</summary>
    private void DrawArcheTypesTab(World world)
    {
        EditorGUILayout.LabelField($"ArcheTypes ({_archeTypes.Count})", EditorStyles.boldLabel);

        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.BeginVertical(GUILayout.Width(position.width * 0.42f));
        _archeTypeListScroll = EditorGUILayout.BeginScrollView(_archeTypeListScroll, GUILayout.MinHeight(280f));
        for (int i = 0; i < _archeTypes.Count; i++)
        {
            ArcheTypeDebugInfo info = _archeTypes[i];
            bool selected = i == _selectedArcheTypeIndex;
            string label = $"{i}. Entities={info.entityCount}, Components={info.componentCount}";
            if (GUILayout.Toggle(selected, label, "Button"))
                _selectedArcheTypeIndex = i;
        }
        EditorGUILayout.EndScrollView();
        EditorGUILayout.EndVertical();

        EditorGUILayout.BeginVertical();
        _archeTypeDetailScroll = EditorGUILayout.BeginScrollView(_archeTypeDetailScroll, GUILayout.MinHeight(280f));
        DrawSelectedArcheTypeDetail(world);
        EditorGUILayout.EndScrollView();
        EditorGUILayout.EndVertical();
        EditorGUILayout.EndHorizontal();
    }

    /// <summary>绘制选中 ArcheType 的详情。</summary>
    private void DrawSelectedArcheTypeDetail(World world)
    {
        if (_selectedArcheTypeIndex < 0 || _selectedArcheTypeIndex >= _archeTypes.Count)
        {
            EditorGUILayout.HelpBox("Select an ArcheType from the left list.", MessageType.Info);
            return;
        }

        ArcheTypeDebugInfo info = _archeTypes[_selectedArcheTypeIndex];
        EditorGUILayout.LabelField("Selected ArcheType", EditorStyles.boldLabel);
        DrawReadOnlyInt("Entity Count", info.entityCount);
        DrawReadOnlyInt("Component Count", info.componentCount);
        DrawReadOnlyText("Mask", info.mask.ToString());

        EditorGUILayout.Space(6f);
        EditorGUILayout.LabelField("Component Types", EditorStyles.boldLabel);
        world.FillComponentTypesByMask(info.mask, _componentTypes);
        DrawTypeList(_componentTypes);

        EditorGUILayout.Space(6f);
        EditorGUILayout.LabelField("Entities", EditorStyles.boldLabel);
        world.FillEntitiesByArcheType(info.mask, _archeTypeEntities);
        int count = Mathf.Min(_archeTypeEntities.Count, MaxPreviewCount);
        for (int i = 0; i < count; i++)
            EditorGUILayout.LabelField(_archeTypeEntities[i].ToString());

        if (_archeTypeEntities.Count > MaxPreviewCount)
            EditorGUILayout.HelpBox($"Only first {MaxPreviewCount} entities are shown.", MessageType.Info);
    }

    /// <summary>绘制 ComponentStore 调试页。</summary>
    private void DrawComponentStoresTab()
    {
        EditorGUILayout.LabelField($"Component Stores ({_componentStores.Count})", EditorStyles.boldLabel);
        _componentStoreSearch = EditorGUILayout.TextField("Search", _componentStoreSearch);
        DrawComponentStoreHeader();

        for (int i = 0; i < _componentStores.Count; i++)
        {
            ComponentStoreDebugInfo info = _componentStores[i];
            string typeName = ShortTypeName(info.componentType);
            if (!TextMatches(typeName, _componentStoreSearch))
                continue;

            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField(typeName, GUILayout.MinWidth(180f));
            EditorGUILayout.LabelField(info.registerID.ToString(), GUILayout.Width(70f));
            EditorGUILayout.LabelField(info.count.ToString(), GUILayout.Width(70f));
            EditorGUILayout.LabelField(info.capacity.ToString(), GUILayout.Width(90f));
            EditorGUILayout.LabelField(info.sparseCapacity.ToString(), GUILayout.Width(110f));
            EditorGUILayout.EndHorizontal();
        }
    }

    /// <summary>绘制 Singleton 调试页。</summary>
    private void DrawSingletonsTab()
    {
        EditorGUILayout.LabelField($"Singletons ({_singletons.Count})", EditorStyles.boldLabel);
        for (int i = 0; i < _singletons.Count; i++)
        {
            SingletonDebugInfo info = _singletons[i];
            EditorGUILayout.BeginVertical("box");
            EditorGUILayout.LabelField(ShortTypeName(info.componentType), EditorStyles.boldLabel);
            DrawReadOnlyText("Entity", info.entity.ToString());
            DrawReadOnlyText("Alive", info.isAlive.ToString());
            EditorGUILayout.EndVertical();
        }
    }

    /// <summary>绘制 WorldEvent 调试页。</summary>
    private void DrawWorldEventsTab()
    {
        EditorGUILayout.LabelField($"World Events ({_events.Count})", EditorStyles.boldLabel);
        DrawWorldEventHeader();
        for (int i = 0; i < _events.Count; i++)
        {
            WorldEventDebugInfo info = _events[i];
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField(ShortTypeName(info.eventType), GUILayout.MinWidth(180f));
            EditorGUILayout.LabelField(info.eventCount.ToString(), GUILayout.Width(80f));
            EditorGUILayout.LabelField(info.oldestFrame.ToString(), GUILayout.Width(110f));
            EditorGUILayout.LabelField(info.newestFrame.ToString(), GUILayout.Width(110f));
            EditorGUILayout.EndHorizontal();
        }
    }

    /// <summary>绘制 System 表头。</summary>
    private static void DrawSystemHeader()
    {
        EditorGUILayout.BeginHorizontal(EditorStyles.helpBox);
        EditorGUILayout.LabelField("Name", EditorStyles.boldLabel, GUILayout.MinWidth(160f));
        EditorGUILayout.LabelField("Sequence", EditorStyles.boldLabel, GUILayout.Width(100f));
        EditorGUILayout.LabelField("Enabled", EditorStyles.boldLabel, GUILayout.Width(60f));
        EditorGUILayout.LabelField("Last", EditorStyles.boldLabel, GUILayout.Width(80f));
        EditorGUILayout.LabelField("Avg", EditorStyles.boldLabel, GUILayout.Width(80f));
        EditorGUILayout.LabelField("Max", EditorStyles.boldLabel, GUILayout.Width(80f));
        EditorGUILayout.LabelField("Ticks", EditorStyles.boldLabel, GUILayout.Width(80f));
        EditorGUILayout.EndHorizontal();
    }

    /// <summary>绘制 ComponentStore 表头。</summary>
    private static void DrawComponentStoreHeader()
    {
        EditorGUILayout.BeginHorizontal(EditorStyles.helpBox);
        EditorGUILayout.LabelField("Type", EditorStyles.boldLabel, GUILayout.MinWidth(180f));
        EditorGUILayout.LabelField("TypeID", EditorStyles.boldLabel, GUILayout.Width(70f));
        EditorGUILayout.LabelField("Count", EditorStyles.boldLabel, GUILayout.Width(70f));
        EditorGUILayout.LabelField("Capacity", EditorStyles.boldLabel, GUILayout.Width(90f));
        EditorGUILayout.LabelField("Sparse", EditorStyles.boldLabel, GUILayout.Width(110f));
        EditorGUILayout.EndHorizontal();
    }

    /// <summary>绘制 WorldEvent 表头。</summary>
    private static void DrawWorldEventHeader()
    {
        EditorGUILayout.BeginHorizontal(EditorStyles.helpBox);
        EditorGUILayout.LabelField("Type", EditorStyles.boldLabel, GUILayout.MinWidth(180f));
        EditorGUILayout.LabelField("Count", EditorStyles.boldLabel, GUILayout.Width(80f));
        EditorGUILayout.LabelField("Oldest Frame", EditorStyles.boldLabel, GUILayout.Width(110f));
        EditorGUILayout.LabelField("Newest Frame", EditorStyles.boldLabel, GUILayout.Width(110f));
        EditorGUILayout.EndHorizontal();
    }

    /// <summary>绘制类型列表。</summary>
    private static void DrawTypeList(List<Type> types)
    {
        if (types == null || types.Count == 0)
        {
            EditorGUILayout.LabelField("None");
            return;
        }

        for (int i = 0; i < types.Count; i++)
            EditorGUILayout.LabelField($"- {ShortTypeName(types[i])}");
    }

    /// <summary>获取当前选中的调试源。</summary>
    private IECSRuntimeDebugSource GetCurrentSource()
    {
        if (_selectedSourceIndex < 0 || _selectedSourceIndex >= _sources.Count)
            return null;

        IECSRuntimeDebugSource source = _sources[_selectedSourceIndex];
        UnityEngine.Object sourceObject = source as UnityEngine.Object;
        if (sourceObject == null)
            return null;

        return source;
    }

    /// <summary>获取当前选中调试源绑定的 World。</summary>
    private World GetCurrentWorld()
    {
        IECSRuntimeDebugSource source = GetCurrentSource();
        return source != null ? source.DebugWorld : null;
    }

    /// <summary>生成调试源显示名称。</summary>
    private static string CreateSourceLabel(IECSRuntimeDebugSource source)
    {
        if (source == null)
            return "Missing Source";

        string sourceName = string.IsNullOrEmpty(source.DebugSourceName) ? "Unnamed" : source.DebugSourceName;
        string typeName = source.GetType().Name;
        return $"{sourceName} ({typeName})";
    }

    /// <summary>读取实体组件数量。</summary>
    private static int GetComponentCount(World world, Entity entity)
    {
        if (world == null)
            return 0;

        if (!world.TryGetEntityDebugInfo(entity, out EntityDebugInfo info))
            return 0;

        return info.componentCount;
    }

    /// <summary>实体搜索匹配。</summary>
    private static bool EntityMatchesSearch(Entity entity, string search)
    {
        if (string.IsNullOrEmpty(search))
            return true;

        return entity.ID.ToString().Contains(search) || entity.Version.ToString().Contains(search) || entity.ToString().IndexOf(search, StringComparison.OrdinalIgnoreCase) >= 0;
    }

    /// <summary>文本搜索匹配。</summary>
    private static bool TextMatches(string text, string search)
    {
        if (string.IsNullOrEmpty(search))
            return true;

        if (string.IsNullOrEmpty(text))
            return false;

        return text.IndexOf(search, StringComparison.OrdinalIgnoreCase) >= 0;
    }

    private static void DrawReadOnlyText(string label, string value)
    {
        EditorGUILayout.LabelField(label, value ?? string.Empty);
    }

    private static void DrawReadOnlyInt(string label, int value)
    {
        EditorGUILayout.LabelField(label, value.ToString());
    }

    private static void DrawReadOnlyFloat(string label, float value)
    {
        EditorGUILayout.LabelField(label, value.ToString("F4"));
    }

    private static string ShortTypeName(Type type)
    {
        return type != null ? type.Name : "None";
    }
}
}
#endif
