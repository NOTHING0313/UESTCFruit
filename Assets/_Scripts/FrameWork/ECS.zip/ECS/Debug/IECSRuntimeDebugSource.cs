using UnityEngine;

namespace ECSFrameWork
{
/// <summary>
/// ECS Runtime Inspector 的运行时数据源接口。
/// 任何持有 World / SimulateRunner 的 MonoBehaviour 都可以实现该接口，让 Editor 工具读取调试数据。
/// </summary>
public interface IECSRuntimeDebugSource
{
    /// <summary>当前可调试的 World；没有初始化时返回 null。</summary>
    World DebugWorld { get; }

    /// <summary>当前驱动 World 的 SimulateRunner；没有使用固定帧 Runner 时可以返回 null。</summary>
    SimulateRunner DebugRunner { get; }

    /// <summary>调试源显示名称。</summary>
    string DebugSourceName { get; }
}

/// <summary>
/// 通用 ECS 调试目标。
/// 如果项目中不是由 TimeSimulator 持有 World，可以把该组件挂到场景对象上，并在启动代码中 Bind 当前 World / Runner。
/// </summary>
public sealed class ECSRuntimeDebugTarget : MonoBehaviour, IECSRuntimeDebugSource
{
    private World _world;
    private SimulateRunner _runner;

    /// <summary>当前可调试的 World。</summary>
    public World DebugWorld => _world;

    /// <summary>当前驱动 World 的 Runner。</summary>
    public SimulateRunner DebugRunner => _runner;

    /// <summary>调试源显示名称。</summary>
    public string DebugSourceName => name;

    /// <summary>绑定当前运行中的 World 与 Runner，供 Runtime Inspector 读取。</summary>
    public void Bind(World world, SimulateRunner runner = null)
    {
        _world = world;
        _runner = runner;
    }

    /// <summary>解除当前调试绑定。</summary>
    public void Unbind()
    {
        _world = null;
        _runner = null;
    }
}
}
