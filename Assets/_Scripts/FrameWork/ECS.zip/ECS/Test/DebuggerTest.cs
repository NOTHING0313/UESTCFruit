using ECSFrameWork;
using UnityEngine;

/// <summary>
/// ECSWorldDebuggerWindow ������ʱ������ڡ�
/// �ҵ����� GameObject �Ϻ�EditorWindow ����ͨ�� IECSRuntimeDebugSource �ҵ�������� World��
/// </summary>
public sealed class ECSWorldDebuggerWindowTestBootstrap : MonoBehaviour, IECSRuntimeDebugSource
{
    private World _world;
    private SimulateRunner _runner;
    private int _spawnIndex;

    public World DebugWorld => _world;
    public SimulateRunner DebugRunner => _runner;
    public string DebugSourceName => $"Window Test Source - {name}";

    private void Awake()
    {
        _world = new World();
        _runner = new SimulateRunner(_world, 0.02f, 4);

        _world.EnableSystemProfile = true;

        CreateTestWorld();
    }

    private void Update()
    {
        _runner?.Update(Time.deltaTime);
    }

    private void OnDestroy()
    {
        _world?.Dispose();
        _world = null;
        _runner = null;
    }

    /// <summary>
    /// ����һ��̶��������ݣ��� ECSWorldDebuggerWindow ��ʾ��
    /// </summary>
    private void CreateTestWorld()
    {
        _world.AddSystem(new WindowDebugMoveSystem());

        _world.SetSingleton(new WindowDebugTimeSingleton(0));

        Entity mover = _world.CreateEntity();
        _world.SetComponent(mover, new WindowDebugPositionComponent(0, 0, 0));
        _world.SetComponent(mover, new WindowDebugVelocityComponent(1, 0, 0));
        _world.SetComponent(mover, new WindowDebugHealthComponent(100, 100));

        Entity staticTarget = _world.CreateEntity();
        _world.SetComponent(staticTarget, new WindowDebugPositionComponent(5, 0, 0));
        _world.SetComponent(staticTarget, new WindowDebugHealthComponent(50, 50));

        Entity positionOnly = _world.CreateEntity();
        _world.SetComponent(positionOnly, new WindowDebugPositionComponent(-3, 0, 0));

        _world.AddWorldEvent(new WindowDebugSpawnEvent(0, mover));
        _world.AddWorldEvent(new WindowDebugSpawnEvent(0, staticTarget));
    }

    /// <summary>
    /// �Ҽ�����˵����ã����ڲ��� EditorWindow �Զ�ˢ�º������Ƿ�仯��
    /// </summary>
    [ContextMenu("Spawn One More Entity")]
    private void SpawnOneMoreEntity()
    {
        if (_world == null)
            return;

        _spawnIndex++;

        Entity entity = _world.CreateEntity();
        _world.SetComponent(entity, new WindowDebugPositionComponent(_spawnIndex * 2, 0, 0));
        _world.SetComponent(entity, new WindowDebugHealthComponent(10 + _spawnIndex, 10 + _spawnIndex));

        int frame = _runner != null ? _runner.CurrentFrameNumber : 0;
        _world.AddWorldEvent(new WindowDebugSpawnEvent(frame, entity));

        Debug.Log($"[ECSWindowTest] Spawned {entity}");
    }
}

/// <summary>
/// ������λ�������
/// </summary>
public struct WindowDebugPositionComponent : IComponentData
{
    public float x;
    public float y;
    public float z;

    public WindowDebugPositionComponent(float x, float y, float z)
    {
        this.x = x;
        this.y = y;
        this.z = z;
    }
}

/// <summary>
/// �������ٶ������
/// </summary>
public struct WindowDebugVelocityComponent : IComponentData
{
    public float x;
    public float y;
    public float z;

    public WindowDebugVelocityComponent(float x, float y, float z)
    {
        this.x = x;
        this.y = y;
        this.z = z;
    }
}

/// <summary>
/// ����������ֵ�����
/// </summary>
public struct WindowDebugHealthComponent : IComponentData
{
    public int currentHealth;
    public int maxHealth;

    public WindowDebugHealthComponent(int currentHealth, int maxHealth)
    {
        this.currentHealth = currentHealth;
        this.maxHealth = maxHealth;
    }
}

/// <summary>
/// ������ SingletonComponent��
/// </summary>
public struct WindowDebugTimeSingleton : IComponentData
{
    public int frame;

    public WindowDebugTimeSingleton(int frame)
    {
        this.frame = frame;
    }
}

/// <summary>
/// ������ WorldEvent��
/// ͬʱ�ṩ FrameNumber �� frameNumber�����ݲ�ͬ�¼�֡�Ŷ�ȡϰ�ߡ�
/// </summary>
public readonly struct WindowDebugSpawnEvent : IWorldEvent
{
    public int FrameNumber { get; }
    public int frameNumber => FrameNumber;
    public readonly Entity entity;

    public WindowDebugSpawnEvent(int frameNumber, Entity entity)
    {
        FrameNumber = frameNumber;
        this.entity = entity;
    }
}

/// <summary>
/// ������ System�������� Systems ҳ����ʾ Profile ���ݡ�
/// </summary>
public sealed class WindowDebugMoveSystem : FixedStepSystemBase
{
    public override SystemTickSequence sequence => default;

    public override void Tick(in SimulationContext context)
    {
        float tickLength = context.tickLength;

        World.ForEach<WindowDebugPositionComponent, WindowDebugVelocityComponent>((Entity entity, ref WindowDebugPositionComponent position, ref WindowDebugVelocityComponent velocity) =>
        {
            position.x += velocity.x * tickLength;
            position.y += velocity.y * tickLength;
            position.z += velocity.z * tickLength;
        });
    }
}