/*
 * 文件说明：World 是 ECS Core 的统一入口，负责整合 Entity、Component、ArcheType、System 与结构变更缓冲。外部业务应优先通过 World 访问 ECS，而不是直接操作各 Manager。
 * 设计约束：ECS Core 逻辑应尽量保持确定性；Unity 表现、输入采样、外部指令通过 Adapter 或 Buffer 接入。
 */

using System.Collections.Generic;

/// <summary>
/// ECS 逻辑世界入口，统一管理 Entity、Component、ArcheType、Query、System 与结构变更缓冲。
/// </summary>
public class World
{
    private EntityManager _entityManager;
    private ComponentManager _componentManager;
    private ArcheTypeManager _archeTypeManager;
    private SystemManager _systemManager;
    private ComponentTypeRegistry _registry;
    private StructuralChangeBuffer _structuralChangeBuffer;
    private SystemChangeBuffer _systemChangeBuffer;

    private WorldStates _currentState = WorldStates.Initialization;

    public StructuralChangeBuffer Commands => _structuralChangeBuffer;
    public WorldStates CurrentState => _currentState;

    public int CreatedEntityCount => _entityManager.CreatedEntityCount;
    public int EntityCapacity => _entityManager.EntityCapacity;
    public int AliveEntityCount => _entityManager.AliveEntityCount;
    public int EntityCount => _entityManager.AliveEntityCount;
    public int FreeEntityCount => _entityManager.FreeEntityCount;
    public int ComponentStoreCount => _componentManager.StoreCount;
    public int ArcheTypeCount => _archeTypeManager.ArcheTypeCount;
    public int SystemCount => _systemManager.SystemCount;
    public int PendingCommandCount => Commands.Count;
    public int PendingSystemCommandCount => _systemManager.PendingSystemCommandCount;
    public int QueryCacheCount => _archeTypeManager.QueryCacheCount;
    public int ArcheTypeVersion => _archeTypeManager.ArcheTypeVersion;

    /// <summary>是否启用 System Tick 耗时统计；关闭后 System 仍正常执行，但不会更新 Profile。</summary>
    public bool EnableSystemProfile
    {
        get => _systemManager.EnableSystemProfile;
        set => _systemManager.EnableSystemProfile = value;
    }

    /// <summary>当前持有的 System 性能统计对象数量。</summary>
    public int SystemProfileCount => _systemManager.ProfileCount;

    /// <summary>
    /// 创建 World，并初始化 Entity、Component、ArcheType、System 与命令缓冲管理器。
    /// </summary>
    public World()
    {
        LoadManagers();
    }

    /// <summary>
    /// 初始化 World 内部所有核心 Manager 与 Buffer。
    /// </summary>
    private void LoadManagers()
    {
        SetWorldState(WorldStates.Initialization);

        _registry = new ComponentTypeRegistry();
        _entityManager = new EntityManager();
        _archeTypeManager = new ArcheTypeManager(_registry);
        _componentManager = new ComponentManager(_entityManager, _archeTypeManager, _registry);
        _structuralChangeBuffer = new StructuralChangeBuffer();
        _systemManager = new SystemManager(this);
    }

    /// <summary>
    /// 切换 World 当前生命周期阶段。
    /// </summary>
    private void SetWorldState(WorldStates state)
    {
        _currentState = state;
    }

    /// <summary>
    /// 判断 World 是否正在释放。
    /// </summary>
    public bool IsDisposing()
    {
        return _currentState == WorldStates.Disposing;
    }

    /// <summary>
    /// 判断 World 是否正在播放 SystemChangeBuffer。
    /// </summary>
    public bool IsSystemOperating()
    {
        return _currentState == WorldStates.SystemOperating;
    }

    /// <summary>
    /// 判断当前阶段是否允许立即执行 Entity/Component 结构修改。
    /// </summary>
    public bool CanExcuteImmediately(ExcuteType excuteType)
    {
        if (_currentState == WorldStates.Disposing)
            return false;

        switch (excuteType)
        {
            case ExcuteType.Add:
            case ExcuteType.Remove:
            case ExcuteType.DestroyEntity:
                return _currentState == WorldStates.Initialization || _currentState == WorldStates.AfterTicking;

            case ExcuteType.Default:
            default:
                return true;
        }
    }

    /// <summary>
    /// 判断当前阶段是否允许立即修改 System 列表。
    /// </summary>
    public bool CanExcuteSystemImmediately(ExcuteType excuteType)
    {
        if (_currentState == WorldStates.Disposing)
            return false;

        switch (excuteType)
        {
            case ExcuteType.Add:
            case ExcuteType.Remove:
            case ExcuteType.DestroyEntity:
                return _currentState == WorldStates.Initialization;

            case ExcuteType.Default:
            default:
                return true;
        }
    }

    /// <summary>
    /// 推进一个逻辑帧：执行 System、播放结构变更、播放 System 变更。
    /// </summary>
    public void Tick(in SimulationContext context)
    {
        if (_currentState == WorldStates.Disposing)
            return;

        try
        {
            SetWorldState(WorldStates.Ticking);
            _systemManager.Tick(in context);

            if (_currentState == WorldStates.Disposing)
                return;

            SetWorldState(WorldStates.AfterTicking);
            PlaybackStructuralChanges();

            if (_currentState == WorldStates.Disposing)
                return;

            SetWorldState(WorldStates.SystemOperating);
            _systemManager.PlaybackSystemChanges();
        }
        finally
        {
            if (_currentState != WorldStates.Disposing)
                SetWorldState(WorldStates.Initialization);
        }
    }

    /// <summary>
    /// 在 AfterTicking 阶段播放 StructuralChangeBuffer。
    /// </summary>
    private void PlaybackStructuralChanges()
    {
        if (_currentState != WorldStates.AfterTicking)
            return;

        _structuralChangeBuffer.Playback(this);
    }

    /// <summary>
    /// 确保 EntityData 底层数组容量至少达到指定长度。
    /// 该方法只预分配容量，不会创建 Entity。
    /// </summary>
    public void EnsureEntityCapacity(int capacity)
    {
        if (_currentState == WorldStates.Disposing)
            return;

        _entityManager.EnsureCapacity(capacity);
    }

    /// <summary>
    /// 确保指定组件 Store 的容量至少达到指定长度。
    /// sparse 和 dense 默认使用相同容量，适合大量 Entity 预热场景。
    /// </summary>
    public void EnsureComponentCapacity<T>(int capacity) where T : struct, IComponentData
    {
        if (_currentState == WorldStates.Disposing)
            return;

        _componentManager.EnsureComponentCapacity<T>(capacity, capacity);
    }

    /// <summary>
    /// 获取指定组件 Store 的 dense 容量；Store 不存在时返回 0。
    /// </summary>
    public int GetComponentStoreCapacity<T>() where T : struct, IComponentData
    {
        return _componentManager.GetStoreCapacity<T>();
    }

    /// <summary>
    /// 按 Entity ID 从小到大枚举当前存活实体。
    /// </summary>
    public IEnumerable<EntityInfo> GetAliveEntities()
    {
        return _entityManager.GetAliveEntities();
    }

    /// <summary>
    /// 创建 EntityQueryBuilder，用于链式构建 ECS 查询。
    /// </summary>
    public EntityQueryBuilder Query()
    {
        return new EntityQueryBuilder(this);
    }

    /// <summary>
    /// 通过组件类型注册表创建单组件 Mask。
    /// </summary>
    internal ComponentMask256 CreateMask<T>() where T : struct, IComponentData
    {
        return _registry.CreateMask<T>();
    }

    /// <summary>
    /// 创建新实体；World 正在释放时返回 Invalid。
    /// </summary>
    public EntityInfo CreateEntity()
    {
        if (_currentState == WorldStates.Disposing)
            return EntityInfo.Invalid;

        return _entityManager.GetEntityInfo();
    }

    /// <summary>
    /// 判断实体句柄是否仍然有效且存活。
    /// </summary>
    public bool IsAlive(EntityInfo entity)
    {
        return _entityManager.IsAlive(entity);
    }

    /// <summary>
    /// 销毁实体；Tick 中调用时进入 StructuralChangeBuffer。
    /// </summary>
    public void DestroyEntity(EntityInfo entity)
    {
        if (_currentState == WorldStates.Disposing)
            return;

        if (!_entityManager.IsAlive(entity))
            return;

        if (CanExcuteImmediately(ExcuteType.DestroyEntity))
        {
            DestroyEntityImmediately(entity);
            return;
        }

        Commands.DestroyEntity(entity);
    }

    /// <summary>
    /// 立即销毁实体并移除其所有组件。
    /// </summary>
    internal void DestroyEntityImmediately(EntityInfo entity)
    {
        if (!_entityManager.IsAlive(entity))
            return;

        _componentManager.RemoveAllComponents(entity);
        _entityManager.DestroyEntity(entity);
    }

    /// <summary>
    /// 设置组件；新增组件在禁止立即结构修改的阶段进入 StructuralChangeBuffer。
    /// </summary>
    public void SetComponent<T>(EntityInfo entity, in T component) where T : struct, IComponentData
    {
        if (_currentState == WorldStates.Disposing)
            return;

        if (!_entityManager.IsAlive(entity))
            return;

        bool hasComponent = _componentManager.HasComponent<T>(entity);

        if (hasComponent)
        {
            SetComponentImmediately(entity, in component);
            return;
        }

        if (CanExcuteImmediately(ExcuteType.Add))
        {
            SetComponentImmediately(entity, in component);
            return;
        }

        Commands.SetComponent(entity, in component);
    }

    /// <summary>
    /// 立即设置组件并同步 ArcheType。
    /// </summary>
    internal void SetComponentImmediately<T>(EntityInfo entity, in T component) where T : struct, IComponentData
    {
        if (!_entityManager.IsAlive(entity))
            return;

        _componentManager.SetComponent(entity, in component);
    }

    /// <summary>
    /// 移除组件；禁止立即结构修改时进入 StructuralChangeBuffer。
    /// </summary>
    public bool RemoveComponent<T>(EntityInfo entity) where T : struct, IComponentData
    {
        if (_currentState == WorldStates.Disposing)
            return false;

        if (!_entityManager.IsAlive(entity))
            return false;

        if (!_componentManager.HasComponent<T>(entity))
            return false;

        if (CanExcuteImmediately(ExcuteType.Remove))
            return RemoveComponentImmediately<T>(entity);

        Commands.RemoveComponent<T>(entity);
        return true;
    }

    /// <summary>
    /// 立即移除组件并同步 ArcheType。
    /// </summary>
    internal bool RemoveComponentImmediately<T>(EntityInfo entity) where T : struct, IComponentData
    {
        if (!_entityManager.IsAlive(entity))
            return false;

        return _componentManager.RemoveComponent<T>(entity);
    }


    /// <summary>
    /// 获取组件 ref 引用。
    /// </summary>
    public ref T GetComponent<T>(EntityInfo entity) where T : struct, IComponentData
    {
        return ref _componentManager.GetComponent<T>(entity);
    }

    /// <summary>
    /// 安全尝试读取组件数据。
    /// </summary>
    public bool TryGetComponent<T>(EntityInfo entity, out T component) where T : struct, IComponentData
    {
        if (!_entityManager.IsAlive(entity))
        {
            component = default;
            return false;
        }

        return _componentManager.TryGetComponent(entity, out component);
    }

    /// <summary>
    /// 安全判断实体是否拥有指定组件。
    /// </summary>
    public bool HasComponent<T>(EntityInfo entity) where T : struct, IComponentData
    {
        if (!_entityManager.IsAlive(entity))
            return false;

        return _componentManager.HasComponent<T>(entity);
    }

    /// <summary>
    /// 高频遍历同时拥有 T1 和 T2 的实体，并以 ref 形式暴露组件。
    /// 该方法不会创建 Query 结果 List，适合 MovementSystem 等高频无排序需求的系统。
    /// </summary>
    public int ForEach<T1, T2>(EntityComponentAction<T1, T2> action) where T1 : struct, IComponentData where T2 : struct, IComponentData
    {
        if (_currentState == WorldStates.Disposing)
            return 0;

        return _componentManager.ForEach(action);
    }

    /// <summary>
    /// 高频遍历同时拥有 T1、T2 和 T3 的实体，并以 ref 形式暴露组件。
    /// 该方法不会创建 Query 结果 List，适合 InputMoveSystem 等高频无排序需求的系统。
    /// </summary>
    public int ForEach<T1, T2, T3>(EntityComponentAction<T1, T2, T3> action) where T1 : struct, IComponentData where T2 : struct, IComponentData where T3 : struct, IComponentData
    {
        if (_currentState == WorldStates.Disposing)
            return 0;

        return _componentManager.ForEach(action);
    }

    /// <summary>
    /// 向 World 添加 System。
    /// </summary>
    public void AddSystem(IFixedStepSystem system)
    {
        _systemManager.AddSystem(system);
    }

    /// <summary>
    /// 从 World 移除 System。
    /// </summary>
    public bool RemoveSystem(IFixedStepSystem system)
    {
        return _systemManager.RemoveSystem(system);
    }

    /// <summary>
    /// 清空 World 中的全部 System。
    /// </summary>
    public void ClearSystem()
    {
        _systemManager.ClearSystem();
    }

    /// <summary>
    /// 尝试获取指定 System 的性能统计信息。
    /// </summary>
    public bool TryGetSystemProfile(IFixedStepSystem system, out SystemProfileInfo profile)
    {
        return _systemManager.TryGetSystemProfile(system, out profile);
    }

    /// <summary>
    /// 获取当前所有 System 的性能统计信息。
    /// 返回新的 List，避免外部修改 SystemManager 内部集合。
    /// </summary>
    public List<SystemProfileInfo> GetSystemProfiles()
    {
        return _systemManager.GetSystemProfiles();
    }

    /// <summary>
    /// 重置全部 System 性能统计数据，但不移除已注册的 Profile。
    /// </summary>
    public void ResetSystemProfiles()
    {
        _systemManager.ResetSystemProfiles();
    }

    /// <summary>
    /// 释放 World，清理结构命令、System 命令与全部 System。
    /// </summary>
    public void Dispose()
    {
        if (_currentState == WorldStates.Disposing)
            return;

        SetWorldState(WorldStates.Disposing);

        _structuralChangeBuffer.Clear();
        _systemManager.ClearPendingSystemChanges();
        _systemManager.ClearSystemImmediately();
        _systemManager.ClearPendingSystemChanges();
    }

    /// <summary>
    /// 执行 QueryDescription 查询，并把结果填充到外部 List 中。
    /// sorted 为 true 时，会按 Entity ID / Version 排序。
    /// </summary>
    public int FillQuery(EntityQueryDescription query, List<EntityInfo> results, bool sorted = false)
    {
        if (results == null)
            return 0;

        results.Clear();

        _archeTypeManager.FillEntityByQuery(query, results);

        if (sorted)
            results.Sort(EntityInfoComparer.Instance);

        return results.Count;
    }

    /// <summary>
    /// 获取当前 World 的只读统计快照。
    /// 该方法不会修改 World 状态，主要用于 Debug、测试、性能观测和 Editor 面板展示。
    /// </summary>
    public WorldStatistics GetStatistics()
    {
        return new WorldStatistics(
            CreatedEntityCount,
            AliveEntityCount,
            FreeEntityCount,
            ComponentStoreCount,
            ArcheTypeCount,
            QueryCacheCount,
            ArcheTypeVersion,
            SystemCount,
            PendingCommandCount,
            PendingSystemCommandCount,
            _currentState
        );
    }
}

/// <summary>
/// World 生命周期阶段。
/// </summary>
public enum WorldStates
{
    /// <summary>
    /// 初始化或空闲阶段；允许立即创建 Entity、添加组件和调整 System。
    /// </summary>
    Initialization = 0,

    /// <summary>
    /// System 正在 Tick；新增/移除组件、销毁 Entity 等结构变化会进入 StructuralChangeBuffer。
    /// </summary>
    Ticking = 1,

    /// <summary>
    /// 当前逻辑帧的 System Tick 已结束，正在播放 StructuralChangeBuffer。
    /// </summary>
    AfterTicking = 2,

    /// <summary>
    /// 正在播放 SystemChangeBuffer；用于统一处理 System 增删。
    /// </summary>
    SystemOperating = 3,

    /// <summary>
    /// World 正在释放或已经释放；对外修改请求会被忽略。
    /// </summary>
    Disposing = 4,
}

/// <summary>
/// World 内部用于判断操作是否允许立即执行的修改类型。
/// </summary>
/// <remarks>
/// 名称 ExcuteType 保留当前代码命名，后续若统一重命名为 ExecuteType，需要同步修改所有调用点。
/// </remarks>
public enum ExcuteType
{
    /// <summary>不改变结构的普通操作。</summary>
    Default = 0,

    /// <summary>新增组件或新增 System。</summary>
    Add = 1,

    /// <summary>移除组件或移除 System。</summary>
    Remove = 2,

    /// <summary>销毁 Entity。</summary>
    DestroyEntity = 3,
}
