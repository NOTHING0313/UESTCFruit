namespace Utility.EventCenter
{
    public interface IEventData { }
    /// <summary>
    /// �޲��¼��̳иýӿ�
    /// </summary>
    public interface INullDataEvent : IEventData { }
    /// <summary>
    /// ���ֵ�仯�Ľӿ�
    /// </summary>
    /// <typeparam name="TValue"></typeparam>
    public interface IValueChangedEvent<TValue> : IEventData
    {
        TValue OriginValue { get; }
        TValue CurrentValue { get; }
    }
}
