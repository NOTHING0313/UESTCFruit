using ECSFrameWork;
using PoolSystem;
using UnityEngine;

namespace View
{
    public class GameObjectPoolViewInstanceProvider : IViewInstanceProvider
    {
        private readonly Transform _worldViewRoot;

        public GameObjectPoolViewInstanceProvider(Transform worldViewRoot = null)
        {
            _worldViewRoot = worldViewRoot;
        }

        GameObject IViewInstanceProvider.Spawn(GameObject prefab, Vector3 position, Quaternion rotation)
        {
            if (prefab == null) return null;
            GameObject instance = GameObjectPoolCenter.Instance.GetInstance(prefab, position, rotation);
            if (instance == null) return null;
            instance.SetActive(true);
            if (_worldViewRoot != null)
                instance.transform.SetParent(_worldViewRoot, false);
            // �Ƴ� ViewAutoRecycle �Ĺ��أ����������� ViewDestroySystem ����
            return instance;
        }

        void IViewInstanceProvider.Release(GameObject instance)
        {
            if (instance != null)
                GameObjectPoolCenter.Instance.Release(instance);
        }

        void IViewInstanceProvider.Clear() { }
    }
    // ɾ������ ViewAutoRecycle �ඨ��
}